package es.lavavaprecio.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private val navy = Color.rgb(18, 35, 59)
    private val teal = Color.rgb(0, 135, 120)
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var durationInput: EditText
    private var durationMinutes: Int = 150

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        buildUi()
        loadPrices()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 248, 250))
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(TextView(this).apply {
            text = "LavavaPrecio"
            textSize = 30f; setTextColor(navy); setTypeface(null, 1)
        })
        content.addView(TextView(this).apply {
            text = "Elige la hora más barata para lavar"
            textSize = 15f; setTextColor(Color.rgb(90, 105, 120))
            setPadding(0, dp(4), 0, dp(18))
        })
        status = TextView(this).apply {
            text = "Consultando precios PVPC…"
            textSize = 14f; setTextColor(navy)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        content.addView(status, marginBottom(12))

        val settingsTitle = TextView(this).apply {
            text = "Ajustes"
            textSize = 19f
            setTextColor(navy)
            setTypeface(null, 1)
            setPadding(0, dp(4), 0, dp(8))
        }
        content.addView(settingsTitle)

        content.addView(TextView(this).apply {
            text = "Duración del programa (minutos)"
            textSize = 14f
            setTextColor(Color.rgb(70, 85, 100))
        }, marginBottom(5))

        durationInput = EditText(this).apply {
            setText("150")
            hint = "Ej. 150"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        content.addView(durationInput, marginBottom(8))

        val refresh = Button(this).apply {
            text = "Guardar duración y actualizar"
            setOnClickListener {
                val minutes = durationInput.text.toString().toIntOrNull()
                if (minutes == null || minutes !in 15..600) {
                    Toast.makeText(this@MainActivity, "Introduce una duración entre 15 y 600 minutos.", Toast.LENGTH_LONG).show()
                } else {
                    durationMinutes = minutes
                    getSharedPreferences("settings", MODE_PRIVATE).edit().putInt("duration_minutes", minutes).apply()
                    loadPrices()
                }
            }
        }
        content.addView(refresh, marginBottom(16))
        durationMinutes = getSharedPreferences("settings", MODE_PRIVATE).getInt("duration_minutes", 150)
        durationInput.setText(durationMinutes.toString())
        setContentView(root)
    }

    private fun loadPrices() {
        status.text = "Consultando los datos de ESIOS…"
        thread {
            try {
                val now = Calendar.getInstance()
                val start = now.timeInMillis
                // Search starts in the next 12 hours, but request enough extra data to price
                // the complete wash cycle even when it finishes after that search window.
                val end = start + (12L * 60L * 60L * 1000L) + durationMinutes.toLong() * 60L * 1000L
                val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                // Indicator 1001 is commonly used for PVPC in ESIOS. If the public API changes,
                // the app displays an explicit error instead of inventing prices.
                val url = URL("https://api.esios.ree.es/indicators/1001?start_date=${fmt.format(Date(start))}&end_date=${fmt.format(Date(end))}")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12000
                    readTimeout = 12000
                    setRequestProperty("Accept", "application/json; application/vnd.esios-api-v2+json")
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-api-key", ""); // Some ESIOS API routes require a registered token.
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) throw Exception("ESIOS respondió HTTP $code. Puede requerir una clave de API.")
                val json = JSONObject(body)
                val indicator = json.optJSONObject("indicator") ?: json
                val values = indicator.optJSONArray("values") ?: throw Exception("No se encontró la lista de precios en la respuesta.")
                val prices = mutableListOf<Pair<Long, Double>>()
                for (i in 0 until values.length()) {
                    val item = values.getJSONObject(i)
                    val dateStr = item.optString("datetime")
                    val value = item.optDouble("value", Double.NaN)
                    if (dateStr.isNotBlank() && !value.isNaN()) {
                        val parsed = try {
                            java.time.OffsetDateTime.parse(dateStr).toInstant().toEpochMilli()
                        } catch (_: Exception) { -1L }
                        if (parsed >= start && parsed < end) prices.add(Pair(parsed, value))
                    }
                }
                if (prices.isEmpty()) throw Exception("ESIOS no devolvió precios para las próximas 12 horas.")
                val sorted = prices.sortedBy { it.first }
                // A cycle starting at each hourly price point lasts 150 min. Estimate cost
                // by integrating the hourly price over the full 2.5-hour cycle.
                val candidates = sorted.mapNotNull { (t, _) ->
                    val cycleEnd = t + durationMinutes.toLong() * 60L * 1000L
                    val segments = sorted.filter { it.first >= t && it.first < cycleEnd }
                    if (segments.size < 2) null else {
                        val weighted = segments.sumOf { (_, p) -> p } / segments.size
                        Triple(t, weighted, segments.size)
                    }
                }.sortedBy { it.second }
                runOnUiThread {
                    if (candidates.isEmpty()) {
                        status.text = "Hay datos, pero no suficientes horas futuras para evaluar un ciclo completo de 150 minutos. Prueba a actualizar más tarde."
                    } else {
                        showResults(candidates[0], candidates.getOrNull(1), sorted)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "No se pudieron cargar los precios en directo.\n\n${e.message ?: "Error de conexión"}\n\nAbre ESIOS para comprobar el PVPC o vuelve a intentarlo."
                    addSourceButton()
                }
            }
        }
    }

    private fun showResults(best: Triple<Long, Double, Int>, second: Triple<Long, Double, Int>?, prices: List<Pair<Long, Double>>) {
        content.removeViews(3, max(0, content.childCount - 3))
        status.text = "Datos recibidos de ESIOS · próximos 12 h"
        val fmt = SimpleDateFormat("EEE d MMM · HH:mm", Locale("es", "ES"))
        fmt.timeZone = TimeZone.getDefault()
        val card1 = resultCard("HORA IDEAL", fmt.format(Date(best.first)), "Precio medio estimado: ${"%.3f".format(best.second)} €/MWh", "Lavado de ${durationMinutes} min · opción de menor precio estimado")
        content.addView(card1, marginBottom(12))
        if (second != null) {
            val card2 = resultCard("SEGUNDA MEJOR OPCIÓN", fmt.format(Date(second.first)), "Precio medio estimado: ${"%.3f".format(second.second)} €/MWh", "Lavado de ${durationMinutes} min · alternativa")
            content.addView(card2, marginBottom(12))
        }
        content.addView(TextView(this).apply {
            text = "Precios horarios consultados"
            textSize = 18f; setTextColor(navy); setTypeface(null, 1)
            setPadding(0, dp(12), 0, dp(8))
        })
        prices.forEach { (time, value) ->
            content.addView(TextView(this).apply {
                text = "${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))}   ·   ${"%.3f".format(value)} €/MWh"
                textSize = 15f; setTextColor(navy); setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(Color.WHITE)
            }, marginBottom(4))
        }
        addSourceButton()
    }

    private fun resultCard(title: String, time: String, price: String, note: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }
        box.addView(TextView(this).apply { text = title; textSize = 12f; setTextColor(teal); setTypeface(null, 1) })
        box.addView(TextView(this).apply { text = time; textSize = 25f; setTextColor(navy); setTypeface(null, 1); setPadding(0, dp(7), 0, dp(6)) })
        box.addView(TextView(this).apply { text = price; textSize = 15f; setTextColor(navy) })
        box.addView(TextView(this).apply { text = note; textSize = 12f; setTextColor(Color.DKGRAY); setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun addSourceButton() {
        val b = Button(this).apply {
            text = "Abrir PVPC oficial de ESIOS"
            setOnClickListener {
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://www.esios.ree.es/es/pvpc")))
            }
        }
        content.addView(b, marginBottom(8))
        if (content.childCount > 3 && content.getChildAt(content.childCount - 1) === b) return
    }

    private fun marginBottom(bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
