plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "es.lavavaprecio.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "es.lavavaprecio.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
