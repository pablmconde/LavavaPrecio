# LavavaPrecio — proyecto Android

Aplicación Android nativa en Kotlin para consultar el PVPC de ESIOS y sugerir una hora de inicio para un ciclo configurable. La duración predeterminada es 150 minutos y se puede cambiar en Ajustes (15–600 minutos); la preferencia queda guardada en el móvil.

## Importante antes de compilar
- Fuente indicada por el usuario: https://www.esios.ree.es/es/pvpc
- La API de ESIOS puede requerir una clave `x-api-key` y sus rutas/indicadores pueden cambiar. El código intenta consultar el indicador 1001, pero si la API rechaza la petición, la aplicación mostrará el error y un botón para abrir la página oficial.
- La clasificación actual es una estimación sencilla basada en los precios horarios devueltos; no representa el coste exacto de un electrodoméstico porque el consumo real del lavavajillas no es uniforme durante los 150 minutos.
- Antes de distribuir o usar a diario, verifica el identificador del indicador y la autorización API vigente en la documentación de ESIOS.

## Cómo generar el APK
1. Descarga e instala Android Studio.
2. Abre la carpeta `LavavaPrecioAndroid` en Android Studio.
3. Espera a que Gradle sincronice el proyecto.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio mostrará la ubicación del APK generado. Copia el APK al móvil y ábrelo para instalarlo; quizá debas autorizar temporalmente la instalación desde esa fuente.

## Mejoras recomendadas
Para una versión fiable, conectar el indicador PVPC correcto mediante una clave de API válida o un servicio intermedio seguro, y calcular el coste por intervalos horarios con los valores y unidades confirmados.
